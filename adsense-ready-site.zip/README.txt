
# Healthy Quick Eats — AdSense-Ready Static Site

This folder contains a lightweight, fast site you can upload to any host (Netlify, Vercel, Hostinger, cPanel, etc.).

## 1) Customize
- Replace **https://www.healthyquickeats.example** in HTML `<link rel="canonical">` and `sitemap.xml` with your real domain.
- Update contact email in **privacy.html** and **terms.html**.
- Replace images/graphics as you like (use `/assets/img`).

## 2) AdSense Setup
1. Apply at https://www.google.com/adsense/
2. In each HTML file, find the comment **"Google AdSense verification code"** in `<head>` and paste the verification/meta tag AdSense gives you.
3. Replace in-article ad placeholders with your real ad unit code.
4. Update **ads.txt** with your real publisher ID in the format:
   `google.com, pub-XXXXXXXXXXXXXXXX, DIRECT, f08c47fec0942fa0`
5. Upload the site and request review in your AdSense dashboard.

## 3) SEO Essentials
- We've included meta descriptions, Open Graph tags, a `sitemap.xml`, and `robots.txt`.
- Add 10–20 original posts before applying for best approval chances. Use `/blog/` as a reference.
- Submit your sitemap to Google Search Console.

## 4) Analytics (Optional but Recommended)
- Paste your GA4 tag where the **Google Analytics placeholder** is in `<head>`.

## 5) Hosting
- Any static hosting works. For cPanel/Hostinger: upload everything under `public_html`.
- For Netlify/Vercel: drag-and-drop the folder in their dashboard.

## 6) Performance Tips
- Keep images under 200 KB when possible.
- Use descriptive titles, H1/H2, and internal links between posts.
- Publish consistently (e.g., 2 posts per week).

Good luck! 🍀
